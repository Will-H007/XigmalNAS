SAS3IRCU
========
This is a Userworld Tool (SAS3IRCU) for RAID configuration on LSI SAS3 Controllers that is designed to run from a host.
Phase 16 GCA Release Version 17.00.00.00
Release Date : 05-APR-18
Package contains binaries for DOS, Windows x86/x64, Linux x86/x64/PPC64/PPC64LE, EFI, FreeBSD i386/amd64, Solaris x86/SPARC, VMware.
Release Notes: IRCU_MPT_GEN3_Phase16.0-17.00.00.00.pdf
